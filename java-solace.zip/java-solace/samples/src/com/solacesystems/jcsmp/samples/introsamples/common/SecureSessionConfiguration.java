/**
 * SecureSessionConfiguration.java
 * 
 * Copyright 2006-2015 Solace Systems, Inc. All rights reserved.
 */

package com.solacesystems.jcsmp.samples.introsamples.common;


public class SecureSessionConfiguration extends SessionConfiguration {

    private String excludeProtocols;
    private String ciphers;
    private String trustStore;
    private String trustStoreFmt;
    private String trustStorePwd;
    private String commonNames;
    private Boolean validateCertificates;
    private Boolean validateCertificateDates;
    private String keyStore;
    private String keyStoreFmt;
    private String keyStorePwd;
    private String privateKeyAlias;
    private String privateKeyPwd;
    
    public SecureSessionConfiguration() {
        ciphers = null;
        trustStore = null;
        trustStoreFmt = null;
        trustStorePwd = null;
        keyStore = null;
        keyStoreFmt = null;
        keyStorePwd = null;
        privateKeyAlias = null;
        privateKeyPwd = null;
        commonNames = null;
        validateCertificates = null;
        validateCertificateDates = null;
    }
    
    public String getExcludeProtocols() {
        return excludeProtocols;
    }
    
    public void setExcludeProtocols(String excludeProtocols) {
        this.excludeProtocols = excludeProtocols;
    }

    public String getCiphers() {
        return ciphers;
    }
    
    public void setCiphers(String ciphers) {
        this.ciphers = ciphers;
    }
    
    public String getTrustStore() {
        return trustStore;
    }
    
    public void setTrustStore(String trustStore) {
        this.trustStore = trustStore;
    }
    
    public String getTrustStoreFmt() {
        return trustStoreFmt;
    }
    
    public void setTrustStoreFmt(String trustStoreFmt) {
        this.trustStoreFmt = trustStoreFmt;
    }
    
    public String getTrustStorePwd() {
        return trustStorePwd;
    }
    
    public void setTrustStorePwd(String trustStorePwd) {
        this.trustStorePwd = trustStorePwd;
    }
    
    public String getCommonNames() {
        return commonNames;
    }
    
    public void setCommonNames(String commonNames) {
        this.commonNames = commonNames;
    }
    
    public Boolean isValidateCertificates() {
        return validateCertificates;
    }
    
    public void setValidateCertificates(boolean validateCertificates) {
        this.validateCertificates = validateCertificates;
    }
    
    public Boolean isValidateCertificateDates() {
        return validateCertificateDates;
    }
    
    public void setValidateCertificateDates(boolean validateCertificateDates) {
        this.validateCertificateDates = validateCertificateDates;
    }

    @Override
    public String toString() {
        StringBuilder bldr = new StringBuilder(super.toString());
        bldr.append(", excludeProtocols=");
        bldr.append(excludeProtocols);
        bldr.append(", ciphers=");
        bldr.append(ciphers);
        bldr.append(", trustStore=");
        bldr.append(trustStore);
        bldr.append(", trustStoreFmt=");
        bldr.append(trustStoreFmt);
        bldr.append(", trustStorePwd=");
        bldr.append(trustStorePwd);
        bldr.append(", keyStore=");
        bldr.append(keyStore);
        bldr.append(", keyStoreFmt=");
        bldr.append(keyStoreFmt);
        bldr.append(", keyStorePwd=");
        bldr.append(keyStorePwd);
        bldr.append(", privateKeyAlias=");
        bldr.append(privateKeyAlias);
        bldr.append(", privateKeyPwd=");
        bldr.append(privateKeyPwd);
        bldr.append(", commonNames=");
        bldr.append(commonNames);
        bldr.append(", validateCertificates=");
        bldr.append(validateCertificates);
        bldr.append(", validateCertificateDates=");
        bldr.append(validateCertificateDates);
        return bldr.toString();
    }

    public void setKeyStore(String keyStore) {
        this.keyStore = keyStore;
    }

    public void setKeyStoreFmt(String keyStoreFmt) {
        this.keyStoreFmt = keyStoreFmt;
    }

    public void setKeyStorePwd(String keyStorePwd) {
        this.keyStorePwd = keyStorePwd;
    }
    
    public void setPrivateKeyAlias(String privateKeyAlias) {
        this.privateKeyAlias = privateKeyAlias;
    }
    
    public void setPrivateKeyPwd(String privateKeyPwd) {
        this.privateKeyPwd = privateKeyPwd;
    }

    public String getKeyStore() {
        return this.keyStore;
    }

    public String getKeyStoreFmt() {
        return this.keyStoreFmt;
    }
    
    public String getKeyStorePwd() {
        return this.keyStorePwd;
    }
    
    public String getPrivateKeyAlias() {
        return this.privateKeyAlias;
    }
    
    public String getPrivateKeyPwd() {
        return this.privateKeyPwd;
    }
}
